# GHS Kotki Bala PTC Fund Management System
**Government High School Kotki Bala Hangu, Khyber Pakhtunkhwa, Pakistan**

A complete, mobile-friendly, 100% offline-first Parent Teacher Council (PTC) Fund management system designed for school administrators, Headmasters, and PTC in-charges.

---

## 🌟 Key Features

1. **Dashboard & Financial Summary:**
   - Real-time computation of **Total PTC Income**, **Total PTC Expenses**, and **Net Remaining Balance** in Pakistani Rupees (PKR ₨).
   - Instant surplus/deficit budget indicators.
   - Quick action buttons for recording income, expenses, CSV export, and ledger reporting.

2. **Complete Transaction Management:**
   - Add, edit, and delete both Income and Expense transactions.
   - **Fields:**
     - Date
     - Sequential Receipt/Voucher Number (e.g., `VR-2024-001`, `REC-2024-001`)
     - Description / Payee / Particulars
     - Standardized PTC Categories
     - Amount in PKR (₨)
     - Remarks / PTC Resolution & Approval References
   - **Single Voucher Slip View:** Generate and print official single transaction payment/receipt vouchers with signature blocks.

3. **Standard KP PTC Categories:**
   - **Income:** Provincial Government PTC Grant, Farogh-e-Taleem Fund (FTF), Community Donations, Exam Fee Share, Other Income.
   - **Expense:** School Purchases & Equipment, Repairs & Maintenance (Civil/Sanitary/Electrical), Stationery & Printing, Furniture & Fixtures, Sanitation & Utilities, Student Welfare & Emergency Aid, Other Expenses.

4. **Search, Filtering & Sorting:**
   - Instant search across descriptions, voucher numbers, remarks, and categories.
   - Quick filter pills (All, Income Only, Expense Only).
   - Specific category selector.
   - Date range filters (From Date / To Date).
   - Sorting options: Date (Newest/Oldest), Amount (High-to-Low, Low-to-High).

5. **Official Audit Ledger & Reports:**
   - Print-ready KP Elementary & Secondary Education Department PTC format.
   - Chronological itemized ledger table with automatic running balance calculation.
   - Formal signature blocks for **Headmaster / Chairman PTC**, **Secretary / Teacher In-charge**, and **Parent Representative**.
   - One-click **Export to CSV (Excel)** with UTF-8 BOM encoding.

6. **100% Offline-First (No Internet / No Login / No Server):**
   - All records are saved securely inside the device's local **IndexedDB** database (`GHSKotkiBalaPTCFundDB`).
   - Zero reliance on external CDNs, external web fonts, or cloud servers.
   - High data privacy: financial records never leave the physical device.

7. **Full Backup & Restore:**
   - Download complete JSON database backups at any time.
   - Restore or merge records from a backup file with data integrity checks.

8. **PWA & Android Support:**
   - Web App Manifest with 192×192 and 512×512 icons (`icon-192.png`, `icon-512.png`).
   - Service Worker (`service-worker.js`) caching all assets for instant offline reopening.
   - Bundled Android APK with custom launcher icon, native file picker, and printing integration.

---

## 🚀 How to Deploy to GitHub Pages (Step-by-Step)

You can host this web application completely free on GitHub Pages in under 2 minutes:

1. **Push or Upload to a GitHub Repository:**
   - Create a new public or private repository on [GitHub](https://github.com/) (e.g. `ghs-kotki-bala-ptc`).
   - Push this codebase to GitHub:
     ```bash
     git init
     git add .
     git commit -m "Initial commit of GHS Kotki Bala PTC Fund app"
     git branch -M main
     git remote add origin https://github.com/<YOUR-USERNAME>/ghs-kotki-bala-ptc.git
     git push -u origin main
     ```

2. **Enable GitHub Pages:**
   - Open your repository on GitHub.
   - Navigate to **Settings** (gear icon) → **Pages** (in the left sidebar).
   - Under **Build and deployment**:
     - Source: Select **Deploy from a branch**.
     - Branch: Select `main` (or `master`) and folder `/(root)`.
     - Click **Save**.

3. **Access Your Live App:**
   - Within 1–2 minutes, GitHub Pages will deploy your site to:
     `https://<YOUR-USERNAME>.github.io/ghs-kotki-bala-ptc/`
   - Open the link on any Android phone, tablet, or PC!

---

## 📱 How to Test Offline Functionality

1. **Testing on Android Phone (Chrome / Edge / Samsung Internet):**
   - Open the deployed GitHub Pages URL on your Android phone.
   - Tap the browser menu (three dots) → select **"Install app"** or **"Add to Home screen"**.
   - An icon titled **"PTC Fund"** with the school crest will appear on your phone's home screen.
   - Now, switch your phone to **Airplane Mode** (disconnect Wi-Fi and mobile data).
   - Tap the **PTC Fund** icon on your home screen.
   - **Result:** The application opens instantly, displays the "Offline (Local)" badge, and allows adding, editing, viewing, and exporting transactions without internet connection!

2. **Testing in Desktop Browser (Chrome / Edge DevTools):**
   - Open `index.html` via a local web server (e.g., `python3 -m http.server 8080`) or GitHub Pages.
   - Press `F12` to open Developer Tools.
   - Go to the **Network** or **Application** tab.
   - Under the Network tab, change the throttling dropdown from **"No throttling"** to **"Offline"**.
   - Refresh the page (`Ctrl + R` or `Cmd + R`).
   - Notice the green online badge switches to **"Offline (Local)"** and all records remain fully accessible through IndexedDB!

---

## 📁 Source Files Included

- `index.html`: Responsive single-page application with embedded Material/Emerald styling, SVG icons, and IndexedDB engine.
- `manifest.json`: Web App Manifest for Android PWA installation.
- `service-worker.js`: Offline cache-first service worker.
- `icon-192.png`: 192×192 PWA launcher icon.
- `icon-512.png`: 512×512 PWA launcher icon.
- `app/src/main/assets/www/`: Bundled web application assets inside the Android APK.
- `app/src/main/java/com/example/MainActivity.kt`: Android host activity with WebView, printing, and file chooser.
- `metadata.json`: Platform identity.
