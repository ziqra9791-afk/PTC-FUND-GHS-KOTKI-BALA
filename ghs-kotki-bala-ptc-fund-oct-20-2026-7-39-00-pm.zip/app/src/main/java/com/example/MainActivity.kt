package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
  private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    fileChooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
          if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val clipData = result.data?.clipData
            val dataUri = result.data?.data
            val results: Array<Uri>? =
                when {
                  clipData != null -> {
                    Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                  }
                  dataUri != null -> arrayOf(dataUri)
                  else -> null
                }
            fileChooserCallback?.onReceiveValue(results)
          } else {
            fileChooserCallback?.onReceiveValue(null)
          }
          fileChooserCallback = null
        }

    setContent {
      MyApplicationTheme {
        Surface(
            modifier = Modifier.fillMaxSize().systemBarsPadding(),
            color = MaterialTheme.colorScheme.background,
        ) {
          PTCFundAppScreen(
              onOpenFileChooser = { callback, intent ->
                fileChooserCallback = callback
                fileChooserLauncher.launch(intent)
              },
              onPrintRequested = { webView ->
                val printManager = getSystemService(Context.PRINT_SERVICE) as? PrintManager
                printManager?.print(
                    "GHS_Kotki_Bala_PTC_Ledger",
                    webView.createPrintDocumentAdapter("PTC_Ledger"),
                    PrintAttributes.Builder().build(),
                )
              },
          )
        }
      }
    }
  }
}

class WebAppInterface(private val onPrint: () -> Unit) {
  @JavascriptInterface
  fun printDocument() {
    onPrint()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PTCFundAppScreen(
    onOpenFileChooser: (ValueCallback<Array<Uri>>, Intent) -> Unit,
    onPrintRequested: (WebView) -> Unit,
) {
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  BackHandler(enabled = webViewInstance?.canGoBack() == true) {
    webViewInstance?.goBack()
  }

  AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { context ->
        WebView(context).apply {
          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
          }

          addJavascriptInterface(
              WebAppInterface {
                post { onPrintRequested(this) }
              },
              "AndroidAppBridge",
          )

          webViewClient =
              object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?,
                ): Boolean {
                  return false // keep in WebView
                }
              }

          webChromeClient =
              object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?,
                ): Boolean {
                  if (filePathCallback == null) return false
                  val intent =
                      fileChooserParams?.createIntent()
                          ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "*/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                          }
                  onOpenFileChooser(filePathCallback, intent)
                  return true
                }
              }

          loadUrl("file:///android_asset/www/index.html")
          webViewInstance = this
        }
      },
      update = { view ->
        webViewInstance = view
      },
  )
}
